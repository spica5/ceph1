/*-
 * The variables in this vendor.h file can be used to provide vendor specific
 * strings to the properities of the WNBD driver. Replace the contents of
 * this file as necessary.
 */

#define WNBD_COMPANY_STR "WNBD"
#define WNBD_FILEDESCRIPTION_STR "WNBD"
#define WNBD_PRODUCTNAME_STR "WNBD"

