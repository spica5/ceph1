//
// pch.h
//

#pragma once

#define _CRT_RAND_S
#include <stdlib.h>
#include <iostream>
#include <string>

#include <windows.h>

#define _NTSCSI_USER_MODE_
#include <scsi.h>

#include "gtest/gtest.h"

#include <wnbd.h>
